# AI State
### UI Display Meter

## Features

- Displays AI flags (Enabled, Paused, Idle, Walking)
- Uses a single persistent text UI element
- Safe for reuse with other UI modules
